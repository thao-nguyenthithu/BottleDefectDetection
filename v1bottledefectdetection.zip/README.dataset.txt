# Project Bottle Defect Detection > v1BottleDefectDetection
https://universe.roboflow.com/bottle-defect-detection-8leya/project-bottle-defect-detection-5zy5f

Provided by a Roboflow user
License: CC BY 4.0

